#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <thirdparty/doctest/doctest.h>
