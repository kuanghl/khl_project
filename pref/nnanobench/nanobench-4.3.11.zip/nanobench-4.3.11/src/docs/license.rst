===========
MIT License
===========

.. include:: ../../LICENSE
