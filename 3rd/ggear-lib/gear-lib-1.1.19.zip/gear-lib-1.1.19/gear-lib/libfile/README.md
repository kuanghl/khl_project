## libfile
This is a simple libfile library.

support io/fio and inotify
