## libdarray
This is a simple libdarray library.

