## libworkq
This is a simple libworkq library.
https://blog.csdn.net/dodng12/article/details/8840271?utm_medium=distribute.pc_relevant_t0.none-task-blog-BlogCommendFromMachineLearnPai2-1.baidujs&dist_request_id=1328740.27336.16169165899554765&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-BlogCommendFromMachineLearnPai2-1.baidujs

