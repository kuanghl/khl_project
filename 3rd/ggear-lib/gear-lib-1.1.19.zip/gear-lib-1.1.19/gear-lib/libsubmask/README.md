## libsubmask
This is a simple libsubmask library. 
support linux and windows, from ip and mask to get ip range, mask/prefix transform 



