## libsock
This is a simple libsock library.

* wrapper of connect/bind/listen/send/recv/ api of lowlevel socket api
* socket external of server/client highlevel async api
* add new PTCP socket type as pseudo-tcp
