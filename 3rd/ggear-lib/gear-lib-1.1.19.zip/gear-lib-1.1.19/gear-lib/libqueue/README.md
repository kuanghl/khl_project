##libqueue
This is a simple libqueue library.

