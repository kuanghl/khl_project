## libuac
This is a simple libuac library.

ffplay -ar 48000 -channels 2 -f s16le -i uac.pcm
ffplay -formats | grep PCM
