##libstrex
This is a simple libstrex library.

