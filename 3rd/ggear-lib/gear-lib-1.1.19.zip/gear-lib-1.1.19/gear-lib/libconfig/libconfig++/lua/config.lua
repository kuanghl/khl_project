return {
  desc = "xxx",
  auto_live = true,
  url = "xxx",
  crypto = "xxxx",
}