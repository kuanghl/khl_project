## libbase64
This is a simple libbase64 library.

