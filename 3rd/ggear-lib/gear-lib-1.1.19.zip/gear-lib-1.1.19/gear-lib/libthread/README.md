## libthread
This is a simple libthread library.

Refer to atomic of ffmpeg and nginx.
