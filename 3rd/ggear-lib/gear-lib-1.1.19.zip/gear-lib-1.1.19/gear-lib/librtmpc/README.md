## librtmpc
This is a simple librtmpc client library.

