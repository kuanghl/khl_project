## libfsm
This is a simple Finite State Machine library.

