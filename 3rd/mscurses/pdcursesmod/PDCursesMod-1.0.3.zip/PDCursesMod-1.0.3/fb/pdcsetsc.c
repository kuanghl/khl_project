#define LINUX_FRAMEBUFFER_PORT

#include "../vt/pdcsetsc.c"
