#include "../common/pdcclip.c"
