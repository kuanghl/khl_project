(Downloaded from https://www.unicode.org/Public/MAPPINGS/ and subdirs)

Notes on contents of the MAPPING directory:

EASTASIA:
   This directory is obsolete.

ETSI:
   ETSI GSM 03.38 7-bit default alphabet mapping.

ISO8859:
   These are the mapping tables of the ISO 8859 series (1 - 16).

OBSOLETE:
   Obsolete and unsupported mapping tables for historical
   and archival purposes only.

VENDORS:
   Miscellaneous mapping tables for small codesets, typically provided
   by vendors. The majority of current, useful tables are here.
